# Installation 

Use `remotes::install_github("delriaan/architect", subdir = "pkg")` to install.
